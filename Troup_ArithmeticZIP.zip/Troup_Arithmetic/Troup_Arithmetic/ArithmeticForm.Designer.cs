﻿namespace Troup_Arithmetic
{
    partial class ArithmeticForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Number1 = new System.Windows.Forms.Label();
            this.Number2 = new System.Windows.Forms.Label();
            this.Numberbox1 = new System.Windows.Forms.TextBox();
            this.Numberbox2 = new System.Windows.Forms.TextBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonSubtract = new System.Windows.Forms.Button();
            this.buttonMultiply = new System.Windows.Forms.Button();
            this.buttonDivide = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonRandom = new System.Windows.Forms.Button();
            this.Result = new System.Windows.Forms.Label();
            this.Resultbox1 = new System.Windows.Forms.TextBox();
            this.mathPicture = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.mathPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // Number1
            // 
            this.Number1.AutoSize = true;
            this.Number1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Number1.Location = new System.Drawing.Point(0, 0);
            this.Number1.Name = "Number1";
            this.Number1.Size = new System.Drawing.Size(100, 16);
            this.Number1.TabIndex = 0;
            this.Number1.Text = "First Number:";
            // 
            // Number2
            // 
            this.Number2.AutoSize = true;
            this.Number2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Number2.Location = new System.Drawing.Point(0, 42);
            this.Number2.Name = "Number2";
            this.Number2.Size = new System.Drawing.Size(123, 16);
            this.Number2.TabIndex = 2;
            this.Number2.Text = "Second Number:";
            // 
            // Numberbox1
            // 
            this.Numberbox1.Location = new System.Drawing.Point(118, 0);
            this.Numberbox1.Name = "Numberbox1";
            this.Numberbox1.Size = new System.Drawing.Size(100, 20);
            this.Numberbox1.TabIndex = 1;
            // 
            // Numberbox2
            // 
            this.Numberbox2.Location = new System.Drawing.Point(118, 41);
            this.Numberbox2.Name = "Numberbox2";
            this.Numberbox2.Size = new System.Drawing.Size(100, 20);
            this.Numberbox2.TabIndex = 3;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonAdd.Location = new System.Drawing.Point(37, 237);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonAdd.TabIndex = 7;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonSubtract
            // 
            this.buttonSubtract.BackColor = System.Drawing.Color.Lime;
            this.buttonSubtract.Location = new System.Drawing.Point(118, 237);
            this.buttonSubtract.Name = "buttonSubtract";
            this.buttonSubtract.Size = new System.Drawing.Size(75, 23);
            this.buttonSubtract.TabIndex = 8;
            this.buttonSubtract.Text = "Subtract";
            this.buttonSubtract.UseVisualStyleBackColor = false;
            this.buttonSubtract.Click += new System.EventHandler(this.buttonSubtract_Click);
            // 
            // buttonMultiply
            // 
            this.buttonMultiply.BackColor = System.Drawing.Color.DodgerBlue;
            this.buttonMultiply.Location = new System.Drawing.Point(199, 237);
            this.buttonMultiply.Name = "buttonMultiply";
            this.buttonMultiply.Size = new System.Drawing.Size(75, 23);
            this.buttonMultiply.TabIndex = 9;
            this.buttonMultiply.Text = "Multiply";
            this.buttonMultiply.UseVisualStyleBackColor = false;
            this.buttonMultiply.Click += new System.EventHandler(this.buttonMultiply_Click);
            // 
            // buttonDivide
            // 
            this.buttonDivide.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonDivide.Location = new System.Drawing.Point(280, 237);
            this.buttonDivide.Name = "buttonDivide";
            this.buttonDivide.Size = new System.Drawing.Size(75, 23);
            this.buttonDivide.TabIndex = 10;
            this.buttonDivide.Text = "Divide";
            this.buttonDivide.UseVisualStyleBackColor = false;
            this.buttonDivide.Click += new System.EventHandler(this.buttonDivide_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.DarkTurquoise;
            this.buttonClear.Location = new System.Drawing.Point(361, 237);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(75, 23);
            this.buttonClear.TabIndex = 11;
            this.buttonClear.Text = "Clear All";
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonRandom
            // 
            this.buttonRandom.BackColor = System.Drawing.Color.LawnGreen;
            this.buttonRandom.Location = new System.Drawing.Point(253, 23);
            this.buttonRandom.Name = "buttonRandom";
            this.buttonRandom.Size = new System.Drawing.Size(75, 23);
            this.buttonRandom.TabIndex = 4;
            this.buttonRandom.Text = "Random";
            this.buttonRandom.UseVisualStyleBackColor = false;
            this.buttonRandom.Click += new System.EventHandler(this.buttonRandom_Click);
            // 
            // Result
            // 
            this.Result.AutoSize = true;
            this.Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result.Location = new System.Drawing.Point(12, 111);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(56, 16);
            this.Result.TabIndex = 5;
            this.Result.Text = "Result:";
            // 
            // Resultbox1
            // 
            this.Resultbox1.Location = new System.Drawing.Point(93, 111);
            this.Resultbox1.Name = "Resultbox1";
            this.Resultbox1.Size = new System.Drawing.Size(100, 20);
            this.Resultbox1.TabIndex = 6;
            // 
            // mathPicture
            // 
            this.mathPicture.Image = global::Troup_Arithmetic.Properties.Resources.math_clipart_3;
            this.mathPicture.Location = new System.Drawing.Point(388, 23);
            this.mathPicture.Name = "mathPicture";
            this.mathPicture.Size = new System.Drawing.Size(161, 167);
            this.mathPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mathPicture.TabIndex = 12;
            this.mathPicture.TabStop = false;
            this.mathPicture.Click += new System.EventHandler(this.mathPicture_Click);
            // 
            // ArithmeticForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(584, 361);
            this.Controls.Add(this.mathPicture);
            this.Controls.Add(this.Resultbox1);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.buttonRandom);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonDivide);
            this.Controls.Add(this.buttonMultiply);
            this.Controls.Add(this.buttonSubtract);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.Numberbox2);
            this.Controls.Add(this.Numberbox1);
            this.Controls.Add(this.Number2);
            this.Controls.Add(this.Number1);
            this.Name = "ArithmeticForm";
            this.Text = "Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.mathPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Number1;
        private System.Windows.Forms.Label Number2;
        private System.Windows.Forms.TextBox Numberbox1;
        private System.Windows.Forms.TextBox Numberbox2;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonSubtract;
        private System.Windows.Forms.Button buttonMultiply;
        private System.Windows.Forms.Button buttonDivide;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonRandom;
        private System.Windows.Forms.Label Result;
        private System.Windows.Forms.TextBox Resultbox1;
        private System.Windows.Forms.PictureBox mathPicture;
    }
}

