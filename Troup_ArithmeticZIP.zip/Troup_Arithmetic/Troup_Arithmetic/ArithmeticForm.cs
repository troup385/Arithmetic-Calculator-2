﻿using System; 
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Troup_Arithmetic
{
    public partial class ArithmeticForm : Form
    {
        public ArithmeticForm()
        {
            InitializeComponent();
        } 
        

        private void buttonAdd_Click(object sender, EventArgs e)//Addition
        {
            try
            {
                double Number1 = 0, Number2 = 0;
                Number1 = Convert.ToDouble(Numberbox1.Text);
                Number2 = Convert.ToDouble(Numberbox2.Text);
                double Resultbox1var = Number1 + Number2;
                Resultbox1.Text = "" + Resultbox1var;

            } catch { MessageBox.Show("Invalid data was entered."); }

        }

        private void buttonSubtract_Click(object sender, EventArgs e)//Subtraction
        {
            try
            {
                double Number1 = 0, Number2 = 0;
                Number1 = Convert.ToDouble(Numberbox1.Text);
                Number2 = Convert.ToDouble(Numberbox2.Text);
                double Resultbox1var = Number1 - Number2;
                Resultbox1.Text = "" + Resultbox1var;
            }
            catch
            {
                MessageBox.Show("Invalid data was entered.");
            }
            } 

        private void buttonMultiply_Click(object sender, EventArgs e)//Multiplication
        {
            try
            {
                double Number1 = 0, Number2 = 0;
                Number1 = Convert.ToDouble(Numberbox1.Text);
                Number2 = Convert.ToDouble(Numberbox2.Text);
                double Resultbox1var = Number1 * Number2;
                Resultbox1.Text = "" + Resultbox1var;
            }
            catch
            {
                MessageBox.Show("Invalid data was entered.");
            }
            }

        private void buttonDivide_Click(object sender, EventArgs e)//Division
        {
            try
            {
                double Number1 = 0, Number2 = 0;
                Number1 = Convert.ToDouble(Numberbox1.Text);
                Number2 = Convert.ToDouble(Numberbox2.Text);
                double Resultbox1var = Number1 / Number2;
                Resultbox1.Text = "" + Resultbox1var;
            }
          catch
            {
                MessageBox.Show("Invalid data was entered.");

               
            }    
        }

        private void buttonClear_Click(object sender, EventArgs e) //clear the numbers
        {
            Numberbox1.Text = "";
            Numberbox2.Text = "";
            Resultbox1.Text = "";
        }

        private void buttonRandom_Click(object sender, EventArgs e)//generates random numbers
        {
            Random rnd = new Random();
            int Random = rnd.Next(1, 100);
            Numberbox1.Text = Random.ToString();
            Numberbox2.Text = Random.ToString();






        }

        private void mathPicture_Click(object sender, EventArgs e)//Picture disappears when clicked 
        {
            mathPicture.Visible = false;

        }
    }
}
